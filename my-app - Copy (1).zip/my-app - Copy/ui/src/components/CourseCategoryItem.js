import React from "react";

function CourseCategoryItem ({courseName, instructor, description, updateDate, image , price}){

//   class CourseCategoryItem extends React.Component {
//       // constructor cannot be used in fucnction
//   constructor(props){
//     super(props);
//     this.state={
//       isToggleOn: false
//     }
//     this.handleClick=this.handleClick.bind(this);
//   }

//   this.handleClick(){
//     //change state
//     this.setSate(state=> ({
// isToggleOn: !state.isToggleOn
//     }));
//   }
//     render() {
  //     return ()
  //   }
  // }
  //constructor cannot be used in fucnction
//   constructor(props){
//     super(props);
//     this.state={
//       isToggleOn: false
//     }
//     this.handleClick=this.handleClick.bind(this);
//   }

//   this.handleClick(){
//     //change state
//     this.setSate(state=> ({
// isToggleOn: !state.isToggleOn
//     }));
//   }
  
  
  
  
  
  return (
    <div className="courseCategoryItem">
      <img src={image}></img>
      <h1> {courseName} </h1>
      <h3> {instructor} </h3>
      <p> {description} </p>
      <p> {updateDate} </p>            
      <h2> ${price} </h2>
      <button>Buy This Course</button>
 {/* <button onClick={this.handleClick}>
   {this.state.isToggleOn ? "Buy this Course": "Go to Cart"}
 </button> */}
    </div>
  );
}

  

export default CourseCategoryItem;
