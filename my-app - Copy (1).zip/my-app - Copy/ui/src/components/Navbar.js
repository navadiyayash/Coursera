
import React, { useState } from "react";
import logo from "../assets/logo.png";
import {Link} from 'react-router-dom';
import '../Styles/Navbar.scss';
import ReorderIcon from '@mui/icons-material/Reorder';

function Navbar(){
    const [openLinks, setOpenLinks] = useState(false);

  const toggleNavbar = () => {
    setOpenLinks(!openLinks);
  };
    return(
        <div className="navbar">
            
            <div className="leftSidenav" id={openLinks ? "open" : "close"}>
                <img src={logo} />
            
            <div className="hiddenLinks">
                <Link to ="/ourCourse">Our Courses</Link>
                <Link to="/about">About</Link>
                <Link to="/Contact">Contact</Link>
                <input type="text" placeholder="Search.."></input>
                <button type="submit" className="search">Search</button>
                <Link to ="/">Login</Link>
                
                
            </div>
            </div>
            <div className="rightSidenav">
                <Link to="/">Home</Link>
                <Link to ="/ourCourse">Our Courses</Link>
                <Link to="/about">About</Link>
                <Link to="/Contact">Contact</Link>
                <input type="text" placeholder="Search.."></input>
                <button type="submit" className="search">Search</button>
                <Link to ="/login">Login</Link>
                <Link to ="/register">Register</Link>
                <button onClick={toggleNavbar}>
                    <ReorderIcon />
                </button>
                
                
            </div>
       
        </div>
    )
}



export default Navbar;