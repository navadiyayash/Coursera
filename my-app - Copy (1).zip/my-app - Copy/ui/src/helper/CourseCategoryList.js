import Webdesign from "../assets/CourseCategory/webdesign.png";
import Datastructure from "../assets/CourseCategory/datastructure.jpg";
import Databasedesign from "../assets/CourseCategory/databasedesign.jpg";
import Business from "../assets/CourseCategory/business.jpg";
import AI from "../assets/CourseCategory/AI.jpg";
import Cloudcomputing from "../assets/CourseCategory/cloudcomputing.jpg";
// import Video from "../components/Video";
const current = new Date();
export const CourseCategoryList= [
    // const date = `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`;
    {
      courseName: "Web Design and User Experience Engineering",
      instructor: "Vishal Chawla" ,
      description: "Defines the conceptual and technical aspects in web design and learn to create useful and enagaging websites.Learn the web standards and best practices, work flow and tools to master web interfaces",
    //   updateDate :Date.now(),    
    updateDate: `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`,
      image : Webdesign,
      price :60,
    },
    {
        courseName: "Program Structures and Algorithms",
        instructor: "John Andreas" ,
        description: "Master Data structures and  Programming Techniques. Advance your Software Engineering Career by Learning Algorithms through Practice  and Puzzle Solving. Ace job interviews by implementing each algorithmic challenge in this Specialization. Apply the newly-learned algorithmic techniques to real-life  complex problems, such as analyzing a huge social network.",
        // updateDate :Date.now(),
        updateDate: `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`,
        image :Datastructure ,
        price :120,
    },
    {
        courseName: "Database Management and Database Design",
        instructor: "Peter Mckow" ,
        description: " Provides the foundation you need for a career in database development, data warehousing, or business Intelligence.In this course,you will learn to create relational databases, SQL statements to extract information to satisfy business reporting requests, create entity relationship diagrams (ERDs) to design databases.As you develop these skills, you will use either Oracle, MySQL, or PostgreSQL to execute SQL statements and a database diagramming tool such as the ER Assistant.",
        // updateDate :Date.now(),
        updateDate: `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`,
        image : Databasedesign,
        price :120,
     
    },
    {
        courseName: "Business Analytics",
        instructor: "Amber Ashley" ,
        description: "This Specialization provides an introduction to big data analytics for all business professionals, including those with no prior analytics experience. You’ll learn how data analysts describe, predict, and inform business decisions in the specific areas of marketing, human resources, finance, and operations, and you’ll develop basic data literacy and an analytic mindset that will help you make strategic decisions based on data. In the final Capstone Project, you’ll apply your skills to interpret a real-world data set and make appropriate business strategy recommendations.",
        // updateDate :Date.now(),
        updateDate: `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`,
        image : Business,
        price :80,
     
    },
    {
        courseName: " Introduction to Artificial Intelligence",
        instructor: "Jonah Macmillan" ,
        description: "In this course you will learn what Artificial Intelligence means, explore use cases and applications of AI, understand AI concepts and terms like machine learning, deep learning and neural networks. You will be exposed to various issues and concerns surrounding AI such as ethics and bias, & jobs, and get advice from experts about learning and starting a career in AI.  You will also demonstrate AI in action with a mini project.",
        // updateDate :Date.now(),
        updateDate: `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`,
        image : AI,
        price :150,
    },
    {
        courseName: "Cloud Computing",
        instructor: "Nina Sharma" ,
        description: " This course introduces the core concepts of cloud computing. You will gain the foundational knowledge required for understanding cloud computing from a business perspective as also for becoming a cloud practitioner. You will understand the definition and essential characteristics of cloud computing, its history, the business case for cloud computing, and emerging technology usecases enabled by cloud.",
        // updateDate :Date.now(),
        updateDate: `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`,
        image : Cloudcomputing,
        price :75,
    },
  ];
  