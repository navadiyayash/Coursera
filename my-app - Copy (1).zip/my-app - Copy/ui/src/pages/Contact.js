import React, { useState } from 'react'
import '../Styles/Contact.scss';
const Contact = () => {
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [message, setMessage] = useState('')
    const [subject, setSubject] = useState('')
    
    return (
        <div class="container">
            <div class = "contactus">
                <h2>Contact Us</h2>
            </div>
            <h4>
            <p >We'd Love to hear from you, please drop us a line if you've any query.</p>
            </h4>
            <div class="row">
                <div class="column">
                    <form>
                        <label>Email</label>
                        <input 
                            type="text" 
                            id="email" 
                            name="email" 
                            placeholder="email" 
                            value={email}  
                            onChange = {(e) => setEmail(e.target.value)} 
                            />
                        <label>Name</label>
                        <input 
                            type="text" 
                            id="lname" 
                            name="lastname" 
                            placeholder="Your your name.."
                            onChange={(e) => setName(e.target.value)} />
                            <label>Subject</label>
                        <input 
                            type = 'text'
                            placeholder = 'subject'
                            value = { subject }
                            onChange = {(e) => setSubject(e.target.value)}
                        />
                        <h3>
                            How can we help us ?
                            </h3>
                        <textarea 
                            type = 'text'
                            placeholder = 'Message'
                            value = { message }
                            onChange = {
                                (e) => setMessage(e.target.value)
                            }
                        /> 
                        <div className="contactbutton">

                        <input type="button" value="Submit" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
                        }


export default Contact