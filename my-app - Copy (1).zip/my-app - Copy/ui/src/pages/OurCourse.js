import React from "react";
import { CourseCategoryList } from "../helper/CourseCategoryList";
import  CourseCategoryItem from "../components/CourseCategoryItem";
import '../Styles/OurCourse.css';



function Course() {
  return (
    <div className="ourcourse">
      <h1 className="courseTitle">Our Courses</h1>
      
      <div className="courseList">
        {CourseCategoryList.map(CourseCategoryItem, key => {
          return (
            <CourseCategoryItem
              key={key}
              courseName={CourseCategoryItem.courseName}
              instructor={CourseCategoryItem.instructor}
              description={CourseCategoryItem.description}
              updateDate={CourseCategoryItem.updateDate}
              image={CourseCategoryItem.image}
              price={CourseCategoryItem.price}
            />
          );
        })}
      </div>
{/* reconciliation is being used here */}
    </div>
  );
}

export default Course;
