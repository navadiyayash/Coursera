import Nav from './components/Navbar';
import './App.css';
import {BrowserRouter as Router,Switch,Route } from 'react-router-dom';
import Footer from './components/footer';
import Course from './pages/OurCourse';
import About from "./pages/About";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Contact from "./pages/Contact";

import Home from "./pages/Home";

function App() {
  return (
    <div className="App">
      <Router> {/*this is used to Route to a page*/}
      <Nav />
      <Switch>
      <Route path="/" exact component={Home} />
      <Route path="/about" exact component={About} />
      <Route path="/ourCourse" exact component={Course}/>
      <Route path="/Contact" exact component={Contact}/>
      <Route path="/Login" exact component={Login} />
      <Route path="/Register" exact component={Register} />
      </Switch>
      
      </Router>
      
      <Footer />
    </div>
  );
}

export default App;
