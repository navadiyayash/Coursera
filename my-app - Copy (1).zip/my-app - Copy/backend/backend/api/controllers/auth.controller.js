
const authService = require('../services/auth.service');

module.exports = {
    login,
    signup
}

function login(body) {
    return authService.login(body);
}

function signup(body) {
    return authService.signup(body);
}