const router = require('express').Router();

const auth = require('../middlewares/auth');
router.get('/getUserCourses', auth, getUserCourses);
router.post('/registerCourse', auth, registerCourse)

const userCoursesController = require('../controllers/userCourses.controller');

function getUserCourses(req, res, next) {
    const user  = req.user;
    return userCoursesController.getUserCourses(req.query, user);
}

function registerCourse(req, res, next) {
    const user  = req.user;
    return userCoursesController.registerCourse(req.body, user);
}

module.exports = router;
