module.exports = {
    TOKEN_KEY: '123456'
}
