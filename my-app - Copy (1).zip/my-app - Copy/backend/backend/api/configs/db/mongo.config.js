
module.exports = {
    MONGODB_URI: 'mongodb://localhost:27017/app'
}