package com.project.yards.Models;


public class User {

    public String Password;
    public String imageLink;


    public long ID;
    public String Email;
    public String FirstName;
    public String LastName;
    public String EntryDate;


}
