package com.project.yards;


public class StaticInfo {

    public static String EndPoint = "https://ten-yards.firebaseio.com";
    public static String MessagesEndPoint = "https://ten-yards.firebaseio.com/messages";
    public static String FriendsURL = "https://ten-yards.firebaseio.com/friends";
    public static String UsersURL = "https://ten-yards.firebaseio.com/users";
    public static String UserCurrentChatFriendEmail = "";
    public static String TypingStatus = "TypingStatus";
    public static String imageUrl;

    public static String NotificationEndPoint = "https://ten-yards.firebaseio.com/notifications";
    public static String FriendRequestsEndPoint = "https://ten-yards.firebaseio.com/friendrequests";

    public static int ChatAciviityRequestCode = 101;

}
