package com.project.yards.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.project.yards.StaticInfo;
import com.project.yards.R;
import com.project.yards.Services.IFireBaseAPI;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import static com.project.yards.Services.Tools.ENDPOINT;

public class UserLocationActivity extends AppCompatActivity implements OnMapReadyCallback, LocationListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    GoogleApiClient gClient;
    Marker currentMarker;
    LatLng latLngStart;
    double latitude, longitude, latitudeNew, longitudeNew;
    private GoogleMap mMap;
    public boolean normalMap = true;
    LocationRequest lRequest;
    public boolean traffic = false;

    String savedEmail, userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlocation);

        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.userLocMap)).getMapAsync(this);

        getSupportActionBar().setTitle("User Location");
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        SharedPreferences pref = getApplicationContext().getSharedPreferences("LocalUser", 0);
        savedEmail = pref.getString("Email", null);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestLocationPermission();
        }

        if (!((LocationManager) getSystemService(LOCATION_SERVICE)).isProviderEnabled("gps")) {
            startActivityForResult(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"), 1002);
        }

    }

    public class UpdateLocationTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(ENDPOINT)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .build();

            IFireBaseAPI api = retrofit.create(IFireBaseAPI.class);
            // Call<String> call = api.getAllUsersAsJsonString();
            Call<String> call = api.getSingleUserByEmail(StaticInfo.UsersURL + "/" + savedEmail + ".json");
            try {
                return call.execute().body();
            } catch (Exception e) {
                return "null";
            }
        }

        @Override
        protected void onPostExecute(String jsonString) {
            try {
                if (!jsonString.trim().equals("null")) {
                    JSONObject userObj = new JSONObject(jsonString);
                    Firebase firebase = new Firebase(StaticInfo.UsersURL);
                    if (userObj.getString("Email").equals(savedEmail)) {
                        firebase.child(userObj.getString("Email")).child("latitude").setValue(latitude);
                        firebase.child(userObj.getString("Email")).child("longitude").setValue(longitude);
                    }
                } else {
                    Toast.makeText(UserLocationActivity.this, "An error occured", Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }

    public class GetLocationTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(ENDPOINT)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .build();

            IFireBaseAPI api = retrofit.create(IFireBaseAPI.class);
            // Call<String> call = api.getAllUsersAsJsonString();
            Call<String> call = api.getSingleUserByEmail(StaticInfo.UsersURL + "/" + savedEmail + ".json");
            try {
                return call.execute().body();
            } catch (Exception e) {
                return "null";
            }
        }

        @Override
        protected void onPostExecute(String jsonString) {
            if (!jsonString.trim().equals("null")) {

                Firebase firebase = new Firebase(StaticInfo.UsersURL);
                firebase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            if (!ds.child("Email").getValue(String.class).equals(savedEmail)) {
                                latitudeNew = (double) ds.child("latitude").getValue();
                                longitudeNew = (double) ds.child("longitude").getValue();
                                userName = ds.child("FirstName").getValue(String.class) + " " + ds.child("LastName").getValue(String.class);

                                LatLng latLngNew = new LatLng(latitudeNew, longitudeNew);

                                MarkerOptions markerOptions = new MarkerOptions()
                                        .position(latLngNew)
                                        .draggable(true)
                                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.otherslocation_pin));

                                String distance = new DecimalFormat("#.##").format(CalculationByDistance(new LatLng(latitude, longitude)
                                        , new LatLng(latitudeNew, longitudeNew)));

                                Log.e("hmm", " : " + distance);

                                markerOptions.title(userName + " (" + distance + " KM)");

                                if (Double.parseDouble(distance) <= 10.0) {
                                    mMap.addMarker(markerOptions);
                                }
                            }
                        }
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });

            } else {
                Toast.makeText(UserLocationActivity.this, "An error occured", Toast.LENGTH_LONG).show();
            }

        }

    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(UserLocationActivity.this,
                new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                }, 1001);
    }

    public void convertMap(View v) {
        if (this.normalMap) {
            this.mMap.setMapType(2);
            this.normalMap = false;
        } else if (!this.normalMap) {
            this.mMap.setMapType(1);
            this.normalMap = true;
        }
    }

    public void trafficSet(View v) {
        if (!this.traffic && this.mMap != null) {
            this.mMap.setTrafficEnabled(true);
            this.traffic = true;
        } else if (!this.traffic || this.mMap == null) {
            Toast.makeText(UserLocationActivity.this, "Wait for the map to load properly.", Toast.LENGTH_SHORT).show();
        } else {
            this.mMap.setTrafficEnabled(false);
            this.traffic = false;
        }
    }

    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;
        this.gClient = new GoogleApiClient.Builder(this).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();
        this.gClient.connect();
    }

    public void onConnected(@Nullable Bundle bundle) {

        this.lRequest = LocationRequest.create();
        this.lRequest.setPriority(100);
        this.lRequest.setInterval(4000);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(this.gClient, this.lRequest, (LocationListener) this);
        }
    }

    public void onLocationChanged(final Location location) {
        if (location == null) {
            Toast.makeText(this, "Location could not be found", Toast.LENGTH_SHORT).show();
            return;
        }

        LocationServices.FusedLocationApi.removeLocationUpdates(this.gClient, (LocationListener) this);
        this.latLngStart = new LatLng(location.getLatitude(), location.getLongitude());
        MarkerOptions options = new MarkerOptions();
        options.position(this.latLngStart);
        options.icon(BitmapDescriptorFactory.fromResource(R.drawable.userlocation_pin));
        options.title("My Location");
        if (this.currentMarker == null) {
            this.currentMarker = this.mMap.addMarker(options);
        } else {
            this.currentMarker.setPosition(this.latLngStart);
        }

        latitude = location.getLatitude();
        longitude = location.getLongitude();

        UpdateLocationTask updateLocationTask = new UpdateLocationTask();
        updateLocationTask.execute();

        this.mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(this.latLngStart, 15.0f));

        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                String[] title = marker.getTitle().split(" ");
                final String userName = title[0];


                    AlertDialog.Builder builder = new AlertDialog.Builder(UserLocationActivity.this)
                            .setCancelable(false)
                            .setTitle("Connect to " + userName)
                            .setMessage("Are you sure want to connect to " + userName + "?")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                    Intent userIntent = new Intent(UserLocationActivity.this, ActivityAddContact.class);
                                    userIntent.putExtra("username", userName);
                                    startActivity(userIntent);
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            });
                if (!userName.equals("My")) {
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });

        GetLocationTask getLocationTask = new GetLocationTask();
        getLocationTask.execute();

    }

    double CalculationByDistance(LatLng StartP, LatLng EndP) {
        double lat1 = StartP.latitude;
        double lat2 = EndP.latitude;
        double lon1 = StartP.longitude;
        double lon2 = EndP.longitude;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double valueResult = ((double) 6371) * (2.0d * Math.asin(Math.sqrt((Math.sin(dLat / 2.0d) * Math.sin(dLat / 2.0d)) + (((Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))) * Math.sin(dLon / 2.0d)) * Math.sin(dLon / 2.0d)))));
        double meter = valueResult % 1000.0d;
        return meter;
    }

    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        boolean granted = grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            Toast.makeText(this, "Location Permission Granted", Toast.LENGTH_SHORT).show();
            if (!((LocationManager) getSystemService(LOCATION_SERVICE)).isProviderEnabled("gps")) {
                startActivityForResult(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"), 1002);
            }
        } else {
            Toast.makeText(this, "Location Permission Denied", Toast.LENGTH_SHORT).show();
            requestLocationPermission();
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1002 && resultCode == RESULT_OK) {
            LocationServices.FusedLocationApi.requestLocationUpdates(this.gClient, this.lRequest, (LocationListener) this);
        }

    }
}
