package com.project.yards.Models;


public class Message {

    public String FromMail;
    public String ToMail;
    public String Message;
    public String SentDate;
    public String FriendFullName;
    public String imageLink;

    public int rowid;
}
