package com.project.yards.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.project.yards.StaticInfo;
import com.project.yards.Models.User;
import com.project.yards.R;
import com.project.yards.Services.DataContext;
import com.project.yards.Services.IFireBaseAPI;
import com.project.yards.Services.LocalUserService;
import com.project.yards.Services.Tools;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import static com.project.yards.Services.Tools.ENDPOINT;

public class ActivityProfile extends AppCompatActivity {

    private static final int RESULT_LOAD_IMG = 1;
    CircleImageView profileImg;
    StorageReference storageReference;
    FirebaseStorage storage;
    DataContext db = new DataContext(this, null, null, 1);
    String savedEmail, imageUrl;
    Uri filepath;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        User user = LocalUserService.getLocalUserFromPreferences(this);
        profileImg = findViewById(R.id.profileImg);
        TextView tv_UserFullName = (TextView) findViewById(R.id.tv_UserFullName);
        tv_UserFullName.setText(Tools.toProperName(user.FirstName) + " " + Tools.toProperName(user.LastName));

        SharedPreferences pref = getApplicationContext().getSharedPreferences("LocalUser", 0);
        savedEmail = pref.getString("Email", null);

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        new GetProfileImgTask().execute();

        profileImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(ActivityProfile.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
//                    requestStoragePermission();
                } else {
                    loadImagefromGallery();
                }
            }
        });

    }

    public class GetProfileImgTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(ENDPOINT)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .build();

            IFireBaseAPI api = retrofit.create(IFireBaseAPI.class);
            // Call<String> call = api.getAllUsersAsJsonString();
            Call<String> call = api.getSingleUserByEmail(StaticInfo.UsersURL + "/" + savedEmail + ".json");
            try {
                return call.execute().body();
            } catch (Exception e) {
                return "null";
            }
        }

        @Override
        protected void onPostExecute(String jsonString) {
            if (!jsonString.trim().equals("null")) {

                Firebase firebase = new Firebase(StaticInfo.UsersURL);
                firebase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            if (ds.child("Email").getValue(String.class).equals(savedEmail)) {

//                                String profileImageUrl = ds.child("imageUrl").getValue().toString();
//
//                                if (profileImageUrl != null) {
//                                    Glide.with(ActivityProfile.this).load(profileImageUrl).into(profileImg);
//                                }

                            }
                        }
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });

            } else {
                Toast.makeText(ActivityProfile.this, "An error occured", Toast.LENGTH_LONG).show();
            }

        }

    }


    private void loadImagefromGallery() {

        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, RESULT_LOAD_IMG);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            // When an Image is picked
            if (requestCode == RESULT_LOAD_IMG && resultCode == RESULT_OK
                    && null != data) {
                filepath = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filepath);
                    profileImg.setImageBitmap(bitmap);
                    uploadImage();

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        } catch (
                Exception e) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG)
                    .show();
        }
    }

    public class ImageUrlTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(ENDPOINT)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .build();

            IFireBaseAPI api = retrofit.create(IFireBaseAPI.class);
            // Call<String> call = api.getAllUsersAsJsonString();
            User user = LocalUserService.getLocalUserFromPreferences(getApplicationContext());
            Call<String> call = api.getSingleUserByEmail(StaticInfo.UsersURL + "/" + user.Email + ".json");
            try {
                return call.execute().body();
            } catch (Exception e) {
                return "null";
            }
        }

        @Override
        protected void onPostExecute(String jsonString) {
            try {
                if (!jsonString.trim().equals("null")) {
                    JSONObject userObj = new JSONObject(jsonString);
                    Firebase firebase = new Firebase(StaticInfo.UsersURL);
                    if (userObj.getString("Email").equals(savedEmail)) {

                        firebase.child(userObj.getString("Email")).child("imageUrl").setValue(imageUrl);
                    }
                } else {
                    Toast.makeText(ActivityProfile.this, "An error occured", Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }

    public class FriendImageUrlTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(ENDPOINT)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .build();

            IFireBaseAPI api = retrofit.create(IFireBaseAPI.class);
            // Call<String> call = api.getAllUsersAsJsonString();
             user = LocalUserService.getLocalUserFromPreferences(getApplicationContext());
            Call<String> call = api.getSingleUserByEmail(StaticInfo.FriendsURL + "/" + savedEmail + ".json");
            try {
                return call.execute().body();
            } catch (Exception e) {
                return "null";
            }
        }

        @Override
        protected void onPostExecute(String jsonString) {
            try {
                if (!jsonString.trim().equals("null")) {
                    JSONObject userObj = new JSONObject(jsonString);
                    Firebase firebase = new Firebase(StaticInfo.FriendsURL);
                    if (userObj.getString("Email").equals(savedEmail)) {

                        Log.e("mail", "onPostExecute: " + firebase.child(savedEmail).getRef());
                    }
                } else {
                    Toast.makeText(ActivityProfile.this, "An error occured", Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }

    private void uploadImage() {
        if (filepath != null) {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            StorageReference referance = storageReference.child(UUID.randomUUID().toString());
            progressDialog.setTitle("uploading");
            progressDialog.show();
            referance.putFile(filepath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();

                            Task<Uri> uploadTask = taskSnapshot.getStorage().getDownloadUrl();

                            while (!uploadTask.isSuccessful()) ;

                            imageUrl = uploadTask.getResult().toString();

                            new ImageUrlTask().execute();
                            new FriendImageUrlTask().execute();

                            Toast.makeText(ActivityProfile.this, "upload", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            progressDialog.setMessage("uploaded" + (int) progress + "%");
                        }
                    });
        }
    }


}

