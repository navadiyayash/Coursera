package com.project.yards.adapter;


import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.project.yards.StaticInfo;
import com.project.yards.Models.User;
import com.project.yards.R;
import com.project.yards.Services.IFireBaseAPI;
import com.project.yards.Services.Tools;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import static com.project.yards.Services.Tools.ENDPOINT;

public class FriendListAdapter extends ArrayAdapter<User> {

    Context context;
    String savedEmail;
    CircleImageView circleImageView;

    public FriendListAdapter(@NonNull Context context, List<User> contactList) {
        super(context, R.layout.custom_friend_list_row, contactList);
        this.context = context;
    }

    public class GetProfileImgTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(ENDPOINT)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .build();

            IFireBaseAPI api = retrofit.create(IFireBaseAPI.class);
            // Call<String> call = api.getAllUsersAsJsonString();
            Call<String> call = api.getSingleUserByEmail(StaticInfo.UsersURL + "/" + savedEmail + ".json");
            try {
                return call.execute().body();
            } catch (Exception e) {
                return "null";
            }
        }

        @Override
        protected void onPostExecute(String jsonString) {
            if (!jsonString.trim().equals("null")) {

                Firebase firebase = new Firebase(StaticInfo.UsersURL);
                firebase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            if (ds.child("Email").getValue(String.class).equals(ds.getKey())) {


                                //String profileImageUrl = ds.child("imageUrl").getValue().toString();
//                                if (profileImageUrl != null){
//                                    Glide.with(context).load(profileImageUrl).into(circleImageView);
//                                }

                            }
                        }
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });

            } else {
                Toast.makeText(context, "An error occured", Toast.LENGTH_LONG).show();
            }

        }

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View customView = inflater.inflate(R.layout.custom_friend_list_row, parent, false);
        SharedPreferences pref = context.getSharedPreferences("LocalUser", 0);
        savedEmail = pref.getString("Email", null);
        User user = getItem(position);
        circleImageView = customView.findViewById(R.id.frndProfileImg);

        Glide.with(context).load(user.imageLink).into(circleImageView);

        TextView hiddenEmail = (TextView) customView.findViewById(R.id.tv_HiddenEmail);
        TextView tv_Name = (TextView) customView.findViewById(R.id.tv_FriendFullName);
        hiddenEmail.setText(String.valueOf(user.Email));
        tv_Name.setText(Tools.toProperName(user.FirstName) + " " + Tools.toProperName(user.LastName));
        return customView;
    }

}
